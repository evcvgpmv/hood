-- Create DataDeliveryIssues table
CREATE TABLE DataDeliveryIssues (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CompletionWorkIssue BIT NOT NULL,
    DataQualityIssue BIT NOT NULL,
    DashboardUIIssue BIT NOT NULL,
    AssetClassEquity BIT NOT NULL DEFAULT 0,
    AssetClassFX BIT NOT NULL DEFAULT 0,
    AssetClassMacro BIT NOT NULL DEFAULT 0,
    AssetClassCredit BIT NOT NULL DEFAULT 0,
    RegionAMER BIT NOT NULL DEFAULT 0,
    RegionLDN BIT NOT NULL DEFAULT 0,
    RegionAPAC BIT NOT NULL DEFAULT 0,
    IncidentsRaised NVARCHAR(MAX) NULL,
    Comments NVARCHAR(MAX) NULL,
    MailRecipients NVARCHAR(500) NOT NULL,
    ReportDate DATE NOT NULL,
    SubmittedBy NVARCHAR(100) NULL,
    SubmittedDate DATETIME2 DEFAULT GETDATE(),
    Status NVARCHAR(50) DEFAULT 'Submitted',
    ReviewNotes NVARCHAR(MAX) NULL,
    ReviewedBy NVARCHAR(100) NULL,
    ReviewedDate DATETIME2 NULL
);

-- Create index on SubmittedDate for better query performance
CREATE INDEX IX_DataDeliveryIssues_SubmittedDate ON DataDeliveryIssues(SubmittedDate);

-- Create index on Status for filtering
CREATE INDEX IX_DataDeliveryIssues_Status ON DataDeliveryIssues(Status);

-- Create index on ReportDate for filtering and reporting
CREATE INDEX IX_DataDeliveryIssues_ReportDate ON DataDeliveryIssues(ReportDate);

-- Create index on Asset Classes for filtering
CREATE INDEX IX_DataDeliveryIssues_AssetClasses ON DataDeliveryIssues(AssetClassEquity, AssetClassFX, AssetClassMacro, AssetClassCredit);

-- Create index on Regions for filtering
CREATE INDEX IX_DataDeliveryIssues_Regions ON DataDeliveryIssues(RegionAMER, RegionLDN, RegionAPAC);

-- Insert sample data (optional)
INSERT INTO DataDeliveryIssues (
    CompletionWorkIssue, 
    DataQualityIssue, 
    DashboardUIIssue, 
    AssetClassEquity,
    AssetClassFX,
    AssetClassMacro,
    AssetClassCredit,
    RegionAMER,
    RegionLDN,
    RegionAPAC,
    IncidentsRaised, 
    Comments, 
    MailRecipients, 
    ReportDate,
    SubmittedBy
) VALUES (
    1, -- Completion/Work Issue: Yes
    0, -- Data Quality Issue: No
    1, -- Dashboard/UI Issue: Yes
    1, -- Asset Class Equity: Yes
    0, -- Asset Class FX: No
    1, -- Asset Class Macro: Yes
    0, -- Asset Class Credit: No
    1, -- Region AMER: Yes
    0, -- Region LDN: No
    1, -- Region APAC: Yes
    'INC123456789, INC987654321',
    'Sample comment for testing',
    'available.age-mail@barclays.com, kameib.dccstb@barclays.com',
    GETDATE(), -- Report Date: Today
    'System'
); 
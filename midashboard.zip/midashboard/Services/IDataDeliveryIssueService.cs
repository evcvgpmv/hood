using Midashboard.Models;

namespace Midashboard.Services
{
    public interface IDataDeliveryIssueService
    {
        Task<IEnumerable<DataDeliveryIssue>> GetAllAsync();
        Task<DataDeliveryIssue?> GetByIdAsync(int id);
        Task<DataDeliveryIssue> CreateAsync(DataDeliveryIssue dataDeliveryIssue);
        Task<DataDeliveryIssue> UpdateAsync(DataDeliveryIssue dataDeliveryIssue);
        Task<bool> DeleteAsync(int id);
        Task<IEnumerable<DataDeliveryIssue>> GetByStatusAsync(string status);
        Task<IEnumerable<DataDeliveryIssue>> GetByDateRangeAsync(DateTime startDate, DateTime endDate);
    }
} 
using Microsoft.EntityFrameworkCore;
using Midashboard.Data;
using Midashboard.Models;

namespace Midashboard.Services
{
    public class DataDeliveryIssueService : IDataDeliveryIssueService
    {
        private readonly ApplicationDbContext _context;

        public DataDeliveryIssueService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<DataDeliveryIssue>> GetAllAsync()
        {
            return await _context.DataDeliveryIssues
                .OrderByDescending(x => x.SubmittedDate)
                .ToListAsync();
        }

        public async Task<DataDeliveryIssue?> GetByIdAsync(int id)
        {
            return await _context.DataDeliveryIssues.FindAsync(id);
        }

        public async Task<DataDeliveryIssue> CreateAsync(DataDeliveryIssue dataDeliveryIssue)
        {
            dataDeliveryIssue.SubmittedDate = DateTime.UtcNow;
            dataDeliveryIssue.Status = "Submitted";
            
            // Ensure ReportDate is set to previous weekday if not provided
            if (dataDeliveryIssue.ReportDate == default)
            {
                dataDeliveryIssue.ReportDate = GetPreviousWeekday(DateTime.Today);
            }
            
            _context.DataDeliveryIssues.Add(dataDeliveryIssue);
            await _context.SaveChangesAsync();
            
            return dataDeliveryIssue;
        }

        public async Task<DataDeliveryIssue> UpdateAsync(DataDeliveryIssue dataDeliveryIssue)
        {
            var existingIssue = await _context.DataDeliveryIssues.FindAsync(dataDeliveryIssue.Id);
            if (existingIssue == null)
                throw new InvalidOperationException($"DataDeliveryIssue with ID {dataDeliveryIssue.Id} not found.");

            // Update properties
            existingIssue.CompletionWorkIssue = dataDeliveryIssue.CompletionWorkIssue;
            existingIssue.DataQualityIssue = dataDeliveryIssue.DataQualityIssue;
            existingIssue.DashboardUIIssue = dataDeliveryIssue.DashboardUIIssue;
            existingIssue.AssetClassEquity = dataDeliveryIssue.AssetClassEquity;
            existingIssue.AssetClassFX = dataDeliveryIssue.AssetClassFX;
            existingIssue.AssetClassMacro = dataDeliveryIssue.AssetClassMacro;
            existingIssue.AssetClassCredit = dataDeliveryIssue.AssetClassCredit;
            existingIssue.RegionAMER = dataDeliveryIssue.RegionAMER;
            existingIssue.RegionLDN = dataDeliveryIssue.RegionLDN;
            existingIssue.RegionAPAC = dataDeliveryIssue.RegionAPAC;
            existingIssue.IncidentsRaised = dataDeliveryIssue.IncidentsRaised;
            existingIssue.Comments = dataDeliveryIssue.Comments;
            existingIssue.MailRecipients = dataDeliveryIssue.MailRecipients;
            existingIssue.ReportDate = dataDeliveryIssue.ReportDate;
            existingIssue.Status = dataDeliveryIssue.Status;
            existingIssue.ReviewNotes = dataDeliveryIssue.ReviewNotes;
            existingIssue.ReviewedBy = dataDeliveryIssue.ReviewedBy;
            existingIssue.ReviewedDate = dataDeliveryIssue.ReviewedDate;

            await _context.SaveChangesAsync();
            return existingIssue;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var dataDeliveryIssue = await _context.DataDeliveryIssues.FindAsync(id);
            if (dataDeliveryIssue == null)
                return false;

            _context.DataDeliveryIssues.Remove(dataDeliveryIssue);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<DataDeliveryIssue>> GetByStatusAsync(string status)
        {
            return await _context.DataDeliveryIssues
                .Where(x => x.Status == status)
                .OrderByDescending(x => x.SubmittedDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<DataDeliveryIssue>> GetByDateRangeAsync(DateTime startDate, DateTime endDate)
        {
            return await _context.DataDeliveryIssues
                .Where(x => x.SubmittedDate >= startDate && x.SubmittedDate <= endDate)
                .OrderByDescending(x => x.SubmittedDate)
                .ToListAsync();
        }
        
        private DateTime GetPreviousWeekday(DateTime date)
        {
            var previousDay = date.AddDays(-1);
            
            // Keep going back until we find a weekday (Monday = 1, Sunday = 7)
            while (previousDay.DayOfWeek == DayOfWeek.Saturday || previousDay.DayOfWeek == DayOfWeek.Sunday)
            {
                previousDay = previousDay.AddDays(-1);
            }
            
            return previousDay;
        }
    }
} 
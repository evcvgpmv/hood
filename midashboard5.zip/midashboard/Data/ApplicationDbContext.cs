using Microsoft.EntityFrameworkCore;
using Midashboard.Models;

namespace Midashboard.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<DataDeliveryIssue> DataDeliveryIssues { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure DataDeliveryIssue entity
            modelBuilder.Entity<DataDeliveryIssue>(entity =>
            {
                entity.HasKey(e => e.Id);
                
                entity.Property(e => e.CompletionWorkIssue)
                    .IsRequired();
                
                entity.Property(e => e.DataQualityIssue)
                    .IsRequired();
                
                entity.Property(e => e.DashboardUIIssue)
                    .IsRequired();
                
                entity.Property(e => e.AssetClassEquity)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.AssetClassFX)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.AssetClassMacro)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.AssetClassCredit)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.AssetClassSecProd)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.RegionAMER)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.RegionLDN)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.RegionAPAC)
                    .IsRequired()
                    .HasDefaultValue(false);
                
                entity.Property(e => e.MailRecipients)
                    .IsRequired()
                    .HasMaxLength(500);
                
                entity.Property(e => e.ReportDate)
                    .IsRequired()
                    .HasColumnType("date");
                
                entity.Property(e => e.SubmittedBy)
                    .HasMaxLength(100);
                
                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .HasDefaultValue("Submitted");
                
                entity.Property(e => e.ReviewNotes)
                    .HasColumnType("nvarchar(max)");
                
                entity.Property(e => e.ReviewedBy)
                    .HasMaxLength(100);
                
                entity.Property(e => e.SubmittedDate)
                    .HasDefaultValueSql("GETDATE()");
            });
        }
    }
} 
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Midashboard.Models
{
    [Table("DataDeliveryIssues")]
    public class DataDeliveryIssue
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Completion/Work Issue")]
        public bool CompletionWorkIssue { get; set; }

        [Required]
        [Display(Name = "Data Quality Issue")]
        public bool DataQualityIssue { get; set; }

        [Required]
        [Display(Name = "Dashboard/UI Issue")]
        public bool DashboardUIIssue { get; set; }

        [Required]
        [Display(Name = "Asset Class - Equity")]
        public bool AssetClassEquity { get; set; }

        [Required]
        [Display(Name = "Asset Class - FX")]
        public bool AssetClassFX { get; set; }

        [Required]
        [Display(Name = "Asset Class - Macro")]
        public bool AssetClassMacro { get; set; }

        [Required]
        [Display(Name = "Asset Class - Credit")]
        public bool AssetClassCredit { get; set; }

        [Required]
        [Display(Name = "Asset Class - SecProd")]
        public bool AssetClassSecProd { get; set; }

        [Required]
        [Display(Name = "Region - AMER")]
        public bool RegionAMER { get; set; }

        [Required]
        [Display(Name = "Region - LDN")]
        public bool RegionLDN { get; set; }

        [Required]
        [Display(Name = "Region - APAC")]
        public bool RegionAPAC { get; set; }

        [Display(Name = "Incidents Raised")]
        public string? IncidentsRaised { get; set; }

        [Display(Name = "Comments")]
        public string? Comments { get; set; }

        [Required]
        [StringLength(500)]
        [Display(Name = "Mail Recipients")]
        public string MailRecipients { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Report Date")]
        [DataType(DataType.Date)]
        public DateTime ReportDate { get; set; }

        [StringLength(100)]
        [Display(Name = "Submitted By")]
        public string? SubmittedBy { get; set; }

        [Display(Name = "Submitted Date")]
        public DateTime SubmittedDate { get; set; } = DateTime.UtcNow;

        [StringLength(50)]
        public string Status { get; set; } = "Submitted";

        [Display(Name = "Review Notes")]
        public string? ReviewNotes { get; set; }

        [StringLength(100)]
        [Display(Name = "Reviewed By")]
        public string? ReviewedBy { get; set; }

        [Display(Name = "Reviewed Date")]
        public DateTime? ReviewedDate { get; set; }
    }
} 
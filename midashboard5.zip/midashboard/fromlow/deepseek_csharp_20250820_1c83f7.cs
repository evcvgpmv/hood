public interface IDataDeliveryService
{
    Task<List<DataDeliveryIssue>> GetDataDeliveryIssuesAsync(FilterModel filter);
    Task<bool> UpdateReviewedByAsync(int id, string reviewedBy);
    Task<List<string>> GetAssetClassesAsync();
}

public class DataDeliveryService : IDataDeliveryService
{
    private readonly IDbConnectionFactory _connectionFactory;

    public DataDeliveryService(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<List<DataDeliveryIssue>> GetDataDeliveryIssuesAsync(FilterModel filter)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        var query = @"SELECT * FROM DataDeliveryIssues 
                     WHERE ReportDate BETWEEN @DateFrom AND @DateTo";
        
        if (!filter.AssetClasses.Contains("All") && filter.AssetClasses.Any())
        {
            query += " AND AssetClass IN @AssetClasses";
        }
        
        query += " ORDER BY ReportDate DESC, AssetClass";
        
        return (await connection.QueryAsync<DataDeliveryIssue>(query, new {
            DateFrom = filter.DateFrom,
            DateTo = filter.DateTo,
            AssetClasses = filter.AssetClasses
        })).ToList();
    }

    public async Task<bool> UpdateReviewedByAsync(int id, string reviewedBy)
    {
        using var connection = _connectionFactory.CreateConnection();
        
        var result = await connection.ExecuteAsync(
            "UPDATE DataDeliveryIssues SET ReviewedBy = @ReviewedBy, ModifiedDate = GETDATE() WHERE Id = @Id",
            new { Id = id, ReviewedBy = reviewedBy });
            
        return result > 0;
    }

    public async Task<List<string>> GetAssetClassesAsync()
    {
        using var connection = _connectionFactory.CreateConnection();
        
        return (await connection.QueryAsync<string>("SELECT Name FROM AssetClasses ORDER BY Name"))
            .ToList();
    }
}
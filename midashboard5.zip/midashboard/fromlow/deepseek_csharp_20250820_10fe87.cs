public class DataDeliveryIssue
{
    public int Id { get; set; }
    public DateTime CheckDate { get; set; }
    public DateTime ReportDate { get; set; }
    public string AssetClass { get; set; } = string.Empty;
    public DateTime DataDeliveredTime { get; set; }
    public bool? SLATimingMet { get; set; }
    public bool? CompletenessIssue { get; set; }
    public bool? DataQualityIssue { get; set; }
    public bool? DashboardUI { get; set; }
    public string IncidentsRaised { get; set; } = string.Empty;
    public string Comment { get; set; } = string.Empty;
    public bool ReportIsPublished { get; set; }
    public string CheckedBy { get; set; } = string.Empty;
    public string ReviewedBy { get; set; } = string.Empty;
}

public class FilterModel
{
    public DateTime DateFrom { get; set; }
    public DateTime DateTo { get; set; }
    public List<string> AssetClasses { get; set; } = new List<string>();
}
CREATE TABLE DataDeliveryIssues (
    Id INT PRIMARY KEY IDENTITY(1,1),
    CheckDate DATE NOT NULL,
    ReportDate DATE NOT NULL,
    AssetClass NVARCHAR(50) NOT NULL,
    DataDeliveredTime DATETIME NOT NULL,
    SLATimingMet BIT NULL,
    CompletenessIssue BIT NULL,
    DataQualityIssue BIT NULL,
    DashboardUI BIT NULL,
    IncidentsRaised NVARCHAR(MAX) NULL,
    Comment NVARCHAR(MAX) NULL,
    ReportIsPublished BIT NOT NULL DEFAULT 0,
    CheckedBy NVARCHAR(100) NOT NULL,
    ReviewedBy NVARCHAR(100) NULL,
    CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE(),
    ModifiedDate DATETIME2 NULL
);

CREATE TABLE AssetClasses (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL
);

INSERT INTO AssetClasses (Name) VALUES 
('Credit'),
('Equity'),
('Macro'),
('All');
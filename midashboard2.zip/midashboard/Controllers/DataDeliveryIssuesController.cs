using Microsoft.AspNetCore.Mvc;
using Midashboard.Models;
using Midashboard.Services;
using System.ComponentModel.DataAnnotations;

namespace Midashboard.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DataDeliveryIssuesController : ControllerBase
    {
        private readonly IDataDeliveryIssueService _dataDeliveryIssueService;
        private readonly ILogger<DataDeliveryIssuesController> _logger;

        public DataDeliveryIssuesController(
            IDataDeliveryIssueService dataDeliveryIssueService,
            ILogger<DataDeliveryIssuesController> logger)
        {
            _dataDeliveryIssueService = dataDeliveryIssueService;
            _logger = logger;
        }

        // GET: api/DataDeliveryIssues
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DataDeliveryIssue>>> GetDataDeliveryIssues()
        {
            try
            {
                var issues = await _dataDeliveryIssueService.GetAllAsync();
                return Ok(issues);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving data delivery issues");
                return StatusCode(500, "Internal server error occurred while retrieving data delivery issues");
            }
        }

        // GET: api/DataDeliveryIssues/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DataDeliveryIssue>> GetDataDeliveryIssue(int id)
        {
            try
            {
                var dataDeliveryIssue = await _dataDeliveryIssueService.GetByIdAsync(id);

                if (dataDeliveryIssue == null)
                {
                    return NotFound($"Data delivery issue with ID {id} not found");
                }

                return Ok(dataDeliveryIssue);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving data delivery issue with ID {Id}", id);
                return StatusCode(500, "Internal server error occurred while retrieving the data delivery issue");
            }
        }

        // POST: api/DataDeliveryIssues
        [HttpPost]
        public async Task<ActionResult<DataDeliveryIssue>> CreateDataDeliveryIssue([FromBody] DataDeliveryIssue dataDeliveryIssue)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Set default values
                dataDeliveryIssue.SubmittedDate = DateTime.UtcNow;
                dataDeliveryIssue.Status = "Submitted";

                var createdIssue = await _dataDeliveryIssueService.CreateAsync(dataDeliveryIssue);

                _logger.LogInformation("Data delivery issue created with ID {Id}", createdIssue.Id);

                return CreatedAtAction(
                    nameof(GetDataDeliveryIssue), 
                    new { id = createdIssue.Id }, 
                    createdIssue);
            }
            catch (ValidationException ex)
            {
                _logger.LogWarning(ex, "Validation error while creating data delivery issue");
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating data delivery issue");
                return StatusCode(500, "Internal server error occurred while creating the data delivery issue");
            }
        }

        // PUT: api/DataDeliveryIssues/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDataDeliveryIssue(int id, [FromBody] DataDeliveryIssue dataDeliveryIssue)
        {
            try
            {
                if (id != dataDeliveryIssue.Id)
                {
                    return BadRequest("ID mismatch");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var updatedIssue = await _dataDeliveryIssueService.UpdateAsync(dataDeliveryIssue);

                _logger.LogInformation("Data delivery issue with ID {Id} updated", id);

                return Ok(updatedIssue);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Data delivery issue with ID {Id} not found for update", id);
                return NotFound(ex.Message);
            }
            catch (ValidationException ex)
            {
                _logger.LogWarning(ex, "Validation error while updating data delivery issue with ID {Id}", id);
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating data delivery issue with ID {Id}", id);
                return StatusCode(500, "Internal server error occurred while updating the data delivery issue");
            }
        }

        // DELETE: api/DataDeliveryIssues/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDataDeliveryIssue(int id)
        {
            try
            {
                var result = await _dataDeliveryIssueService.DeleteAsync(id);

                if (!result)
                {
                    return NotFound($"Data delivery issue with ID {id} not found");
                }

                _logger.LogInformation("Data delivery issue with ID {Id} deleted", id);

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting data delivery issue with ID {Id}", id);
                return StatusCode(500, "Internal server error occurred while deleting the data delivery issue");
            }
        }

        // GET: api/DataDeliveryIssues/status/{status}
        [HttpGet("status/{status}")]
        public async Task<ActionResult<IEnumerable<DataDeliveryIssue>>> GetDataDeliveryIssuesByStatus(string status)
        {
            try
            {
                var issues = await _dataDeliveryIssueService.GetByStatusAsync(status);
                return Ok(issues);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving data delivery issues by status {Status}", status);
                return StatusCode(500, "Internal server error occurred while retrieving data delivery issues by status");
            }
        }

        // GET: api/DataDeliveryIssues/date-range
        [HttpGet("date-range")]
        public async Task<ActionResult<IEnumerable<DataDeliveryIssue>>> GetDataDeliveryIssuesByDateRange(
            [FromQuery] DateTime startDate, 
            [FromQuery] DateTime endDate)
        {
            try
            {
                if (startDate > endDate)
                {
                    return BadRequest("Start date cannot be after end date");
                }

                var issues = await _dataDeliveryIssueService.GetByDateRangeAsync(startDate, endDate);
                return Ok(issues);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving data delivery issues by date range {StartDate} to {EndDate}", startDate, endDate);
                return StatusCode(500, "Internal server error occurred while retrieving data delivery issues by date range");
            }
        }

        // PATCH: api/DataDeliveryIssues/5/review
        [HttpPatch("{id}/review")]
        public async Task<IActionResult> ReviewDataDeliveryIssue(int id, [FromBody] ReviewRequest reviewRequest)
        {
            try
            {
                var existingIssue = await _dataDeliveryIssueService.GetByIdAsync(id);
                if (existingIssue == null)
                {
                    return NotFound($"Data delivery issue with ID {id} not found");
                }

                // Update review information
                existingIssue.Status = reviewRequest.Status;
                existingIssue.ReviewNotes = reviewRequest.ReviewNotes;
                existingIssue.ReviewedBy = reviewRequest.ReviewedBy;
                existingIssue.ReviewedDate = DateTime.UtcNow;

                var updatedIssue = await _dataDeliveryIssueService.UpdateAsync(existingIssue);

                _logger.LogInformation("Data delivery issue with ID {Id} reviewed by {ReviewedBy}", id, reviewRequest.ReviewedBy);

                return Ok(updatedIssue);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reviewing data delivery issue with ID {Id}", id);
                return StatusCode(500, "Internal server error occurred while reviewing the data delivery issue");
            }
        }
    }

    public class ReviewRequest
    {
        [Required]
        public string Status { get; set; } = string.Empty;
        
        public string? ReviewNotes { get; set; }
        
        [Required]
        public string ReviewedBy { get; set; } = string.Empty;
    }
} 
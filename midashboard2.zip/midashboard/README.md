# Midashboard - Data Delivery Issues Component

A Blazor Server application featuring a Data Delivery Issues component built with .NET 6.

## Features

The Data Delivery Issues component includes:

- **Three Toggle Switches:**
  - Completion/Work Issue (default: Yes)
  - Data Quality Issue (default: No) 
  - Dashboard/UI Issue (default: Yes)

- **Form Fields:**
  - Incidents Raised (textarea)
  - Comments (textarea)
  - Mail Recipients (textarea)

- **Action Buttons:**
  - Send for Review
  - Cancel

## Project Structure

```
Midashboard/
├── Components/
│   └── DataDeliveryIssues.razor          # Main component
├── Pages/
│   ├── Index.razor                       # Sample usage page
│   └── _Host.cshtml                      # Host page
├── Shared/
│   ├── MainLayout.razor                  # Main layout
│   └── NavMenu.razor                     # Navigation menu
├── wwwroot/
│   └── css/
│       ├── site.css                      # Main site styles
│       └── DataDeliveryIssues.css        # Component styles
├── App.razor                             # App component
├── Program.cs                            # Application entry point
├── Midashboard.csproj                    # Project file
└── README.md                             # This file
```

## Getting Started

1. **Prerequisites:**
   - .NET 6 SDK installed
   - Visual Studio 2022 or VS Code

2. **Run the Application:**
   ```bash
   dotnet restore
   dotnet run
   ```

3. **Access the Application:**
   - Navigate to `https://localhost:5001` or `http://localhost:5000`

## Component Usage

### Basic Usage

```razor
<DataDeliveryIssues />
```

### With Two-Way Binding

```razor
<DataDeliveryIssues 
    @bind-CompletionIssue="completionIssue"
    @bind-DataQualityIssue="dataQualityIssue"
    @bind-DashboardIssue="dashboardIssue"
    @bind-IncidentsRaised="incidentsRaised"
    @bind-Comments="comments"
    @bind-MailRecipients="mailRecipients"
    OnSendForReview="HandleSendForReview"
    OnCancel="HandleCancel" />
```

### Component Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `CompletionIssue` | `bool` | `true` | Completion/Work Issue toggle state |
| `DataQualityIssue` | `bool` | `false` | Data Quality Issue toggle state |
| `DashboardIssue` | `bool` | `true` | Dashboard/UI Issue toggle state |
| `IncidentsRaised` | `string` | `""` | Incidents raised text |
| `Comments` | `string` | `""` | Comments text |
| `MailRecipients` | `string` | `""` | Mail recipients text |
| `OnSendForReview` | `EventCallback` | - | Callback when Send for Review is clicked |
| `OnCancel` | `EventCallback` | - | Callback when Cancel is clicked |

## Styling

The component includes:
- Modern toggle switch design
- Responsive layout
- Professional color scheme
- Hover effects and transitions
- Mobile-friendly design

## Customization

You can customize the component by:
- Modifying the CSS in `wwwroot/css/DataDeliveryIssues.css`
- Adding additional parameters
- Extending the component functionality

## Dependencies

- .NET 6.0
- Microsoft.AspNetCore.Components.Web (6.0.0)
- Microsoft.AspNetCore.Components.Server (6.0.0)

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is open source and available under the MIT License. 